import json

clubs = []

# Premier League (20 clubs)
pl_clubs = [
    {"id": 1, "name": "Manchester City", "league_id": 1, "country": "England", "reputation": 95, "budget": 500000000},
    {"id": 2, "name": "Liverpool", "league_id": 1, "country": "England", "reputation": 94, "budget": 450000000},
    {"id": 3, "name": "Arsenal", "league_id": 1, "country": "England", "reputation": 92, "budget": 400000000},
    {"id": 4, "name": "Manchester United", "league_id": 1, "country": "England", "reputation": 93, "budget": 480000000},
    {"id": 5, "name": "Tottenham", "league_id": 1, "country": "England", "reputation": 88, "budget": 350000000},
    {"id": 6, "name": "Chelsea", "league_id": 1, "country": "England", "reputation": 91, "budget": 420000000},
    {"id": 7, "name": "Newcastle United", "league_id": 1, "country": "England", "reputation": 85, "budget": 380000000},
    {"id": 8, "name": "Aston Villa", "league_id": 1, "country": "England", "reputation": 82, "budget": 250000000},
    {"id": 9, "name": "Bournemouth", "league_id": 1, "country": "England", "reputation": 75, "budget": 150000000},
    {"id": 10, "name": "Nottingham Forest", "league_id": 1, "country": "England", "reputation": 76, "budget": 160000000},
    {"id": 11, "name": "Crystal Palace", "league_id": 1, "country": "England", "reputation": 77, "budget": 140000000},
    {"id": 12, "name": "Southampton", "league_id": 1, "country": "England", "reputation": 74, "budget": 130000000},
    {"id": 13, "name": "Wolves", "league_id": 1, "country": "England", "reputation": 78, "budget": 170000000},
    {"id": 14, "name": "West Ham", "league_id": 1, "country": "England", "reputation": 80, "budget": 200000000},
    {"id": 15, "name": "Brighton", "league_id": 1, "country": "England", "reputation": 79, "budget": 180000000},
    {"id": 16, "name": "Everton", "league_id": 1, "country": "England", "reputation": 79, "budget": 175000000},
    {"id": 17, "name": "Fulham", "league_id": 1, "country": "England", "reputation": 76, "budget": 145000000},
    {"id": 18, "name": "Brentford", "league_id": 1, "country": "England", "reputation": 75, "budget": 135000000},
    {"id": 19, "name": "Leicester City", "league_id": 1, "country": "England", "reputation": 80, "budget": 190000000},
    {"id": 20, "name": "Leeds United", "league_id": 1, "country": "England", "reputation": 78, "budget": 165000000},
]

# Championship (24 clubs)
championship_names = [
    "Middlesbrough", "Sheffield United", "Norwich City", "Watford", "Coventry City", "Stoke City",
    "Blackburn Rovers", "Preston North End", "Hull City", "Swansea City", "Cardiff City", "QPR",
    "Millwall", "Rotherham", "Birmingham City", "Huddersfield", "Reading", "Wigan Athletic",
    "Bristol City", "Derby County", "Sunderland", "Ipswich Town", "Plymouth Argyle", "Sheffield Wednesday"
]

for i, name in enumerate(championship_names, start=21):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 2,
        "country": "England",
        "reputation": 70 + (i % 8),
        "budget": 80000000 + (i * 2000000)
    })

# League One (24 clubs)
league_one_names = [
    "Portsmouth", "Bolton Wanderers", "Barnsley", "Peterborough", "Oxford United", "Lincoln City",
    "Wycombe Wanderers", "Charlton Athletic", "Burton Albion", "Exeter City", "Fleetwood Town", "Shrewsbury",
    "Port Vale", "Cheltenham", "Cambridge United", "Morecambe", "Accrington Stanley", "Forest Green",
    "Stevenage", "Northampton", "Carlisle United", "AFC Wimbledon", "Leyton Orient", "Gillingham"
]

for i, name in enumerate(league_one_names, start=45):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 3,
        "country": "England",
        "reputation": 60 + (i % 7),
        "budget": 40000000 + (i * 1000000)
    })

# Add more English lower leagues
league_two_names = [
    "Mansfield Town", "Crewe Alexandra", "Doncaster", "Bradford City", "Colchester", "Grimsby Town",
    "Salford City", "Sutton United", "Harrogate Town", "Barrow", "Crawley Town", "Tranmere Rovers",
]

for i, name in enumerate(league_two_names, start=69):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 4,
        "country": "England",
        "reputation": 55 + (i % 5),
        "budget": 20000000 + (i * 500000)
    })

# Conference/National League (20 clubs)
conf_names = [
    "Wrexham", "Notts County", "Chesterfield", "Oldham Athletic", "Stockport County", "Rochdale",
    "Hartlepool", "York City", "Aldershot", "Eastleigh", "Maidstone United", "Woking",
    "Solihull Moors", "Gateshead", "Altrincham", "Bromley", "Dagenham", "Wealdstone",
    "Boreham Wood", "Halifax Town"
]

for i, name in enumerate(conf_names, start=81):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 5,
        "country": "England",
        "reputation": 50 + (i % 4),
        "budget": 5000000 + (i * 200000)
    })

clubs.extend(pl_clubs)

# La Liga (20 clubs)
laliga_clubs = [
    {"id": 301, "name": "Real Madrid", "league_id": 10, "country": "Spain", "reputation": 96, "budget": 550000000},
    {"id": 302, "name": "Barcelona", "league_id": 10, "country": "Spain", "reputation": 95, "budget": 520000000},
    {"id": 303, "name": "Atletico Madrid", "league_id": 10, "country": "Spain", "reputation": 90, "budget": 400000000},
    {"id": 304, "name": "Sevilla", "league_id": 10, "country": "Spain", "reputation": 85, "budget": 280000000},
    {"id": 305, "name": "Real Sociedad", "league_id": 10, "country": "Spain", "reputation": 83, "budget": 220000000},
    {"id": 306, "name": "Real Betis", "league_id": 10, "country": "Spain", "reputation": 82, "budget": 210000000},
    {"id": 307, "name": "Villarreal", "league_id": 10, "country": "Spain", "reputation": 84, "budget": 250000000},
    {"id": 308, "name": "Athletic Bilbao", "league_id": 10, "country": "Spain", "reputation": 83, "budget": 230000000},
    {"id": 309, "name": "Valencia", "league_id": 10, "country": "Spain", "reputation": 82, "budget": 200000000},
    {"id": 310, "name": "Girona", "league_id": 10, "country": "Spain", "reputation": 76, "budget": 140000000},
    {"id": 311, "name": "Celta Vigo", "league_id": 10, "country": "Spain", "reputation": 77, "budget": 150000000},
    {"id": 312, "name": "Getafe", "league_id": 10, "country": "Spain", "reputation": 75, "budget": 130000000},
    {"id": 313, "name": "Osasuna", "league_id": 10, "country": "Spain", "reputation": 74, "budget": 120000000},
    {"id": 314, "name": "Rayo Vallecano", "league_id": 10, "country": "Spain", "reputation": 73, "budget": 110000000},
    {"id": 315, "name": "Mallorca", "league_id": 10, "country": "Spain", "reputation": 74, "budget": 115000000},
    {"id": 316, "name": "Las Palmas", "league_id": 10, "country": "Spain", "reputation": 72, "budget": 100000000},
    {"id": 317, "name": "Alaves", "league_id": 10, "country": "Spain", "reputation": 73, "budget": 105000000},
    {"id": 318, "name": "Cadiz", "league_id": 10, "country": "Spain", "reputation": 72, "budget": 95000000},
    {"id": 319, "name": "Granada", "league_id": 10, "country": "Spain", "reputation": 73, "budget": 108000000},
    {"id": 320, "name": "Almeria", "league_id": 10, "country": "Spain", "reputation": 71, "budget": 90000000},
]
clubs.extend(laliga_clubs)

# La Liga 2 (22 clubs)
laliga2_names = [
    "Espanyol", "Zaragoza", "Sporting Gijon", "Oviedo", "Valladolid", "Eibar", "Leganes",
    "Levante", "Tenerife", "Racing Santander", "Burgos", "Albacete", "Cartagena",
    "Eldense", "Amorebieta", "Mirandes", "Andorra", "Huesca", "Elche", "Deportivo La Coruna",
    "Racing Ferrol", "Villarreal B"
]

for i, name in enumerate(laliga2_names, start=321):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 11,
        "country": "Spain",
        "reputation": 68 + (i % 6),
        "budget": 60000000 + (i * 1500000)
    })

# Segunda B and Tercera (40 clubs)
spanish_lower = [
    "Cordoba", "Malaga", "Hercules", "Ponferradina", "Badajoz", "Alcorcon", "Fuenlabrada",
    "Castellon", "Recreativo", "Gimnastic", "Sabadell", "Almeria B", "Getafe B", "Rayo B",
    "Real Madrid C", "Barcelona C", "Atletico B", "Valencia B", "Sevilla Atletico", "Real Betis B",
    "Real Sociedad B", "Athletic B", "Villarreal C", "Celta B", "Deportivo B", "Mallorca B",
    "Albacete B", "Cartagena B", "Granada B", "Cadiz B", "Las Palmas B", "Osasuna B",
    "Eibar B", "Leganes B", "Valladolid B", "Sporting B", "Oviedo B", "Racing B", "Zaragoza B", "Tenerife B"
]

for i, name in enumerate(spanish_lower, start=343):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 12,
        "country": "Spain",
        "reputation": 55 + (i % 5),
        "budget": 15000000 + (i * 300000)
    })

# Bundesliga (18 clubs)
bundesliga_clubs = [
    {"id": 401, "name": "Bayern Munich", "league_id": 20, "country": "Germany", "reputation": 95, "budget": 500000000},
    {"id": 402, "name": "Bayer Leverkusen", "league_id": 20, "country": "Germany", "reputation": 87, "budget": 320000000},
    {"id": 403, "name": "RB Leipzig", "league_id": 20, "country": "Germany", "reputation": 86, "budget": 300000000},
    {"id": 404, "name": "Borussia Dortmund", "league_id": 20, "country": "Germany", "reputation": 90, "budget": 380000000},
    {"id": 405, "name": "Union Berlin", "league_id": 20, "country": "Germany", "reputation": 79, "budget": 180000000},
    {"id": 406, "name": "Freiburg", "league_id": 20, "country": "Germany", "reputation": 78, "budget": 160000000},
    {"id": 407, "name": "Eintracht Frankfurt", "league_id": 20, "country": "Germany", "reputation": 82, "budget": 220000000},
    {"id": 408, "name": "Wolfsburg", "league_id": 20, "country": "Germany", "reputation": 81, "budget": 210000000},
    {"id": 409, "name": "Borussia Monchengladbach", "league_id": 20, "country": "Germany", "reputation": 80, "budget": 190000000},
    {"id": 410, "name": "Stuttgart", "league_id": 20, "country": "Germany", "reputation": 79, "budget": 175000000},
    {"id": 411, "name": "Hoffenheim", "league_id": 20, "country": "Germany", "reputation": 78, "budget": 170000000},
    {"id": 412, "name": "Mainz", "league_id": 20, "country": "Germany", "reputation": 76, "budget": 140000000},
    {"id": 413, "name": "Augsburg", "league_id": 20, "country": "Germany", "reputation": 75, "budget": 130000000},
    {"id": 414, "name": "Werder Bremen", "league_id": 20, "country": "Germany", "reputation": 78, "budget": 155000000},
    {"id": 415, "name": "Bochum", "league_id": 20, "country": "Germany", "reputation": 74, "budget": 120000000},
    {"id": 416, "name": "FC Koln", "league_id": 20, "country": "Germany", "reputation": 77, "budget": 148000000},
    {"id": 417, "name": "Heidenheim", "league_id": 20, "country": "Germany", "reputation": 73, "budget": 110000000},
    {"id": 418, "name": "Darmstadt", "league_id": 20, "country": "Germany", "reputation": 72, "budget": 100000000},
]
clubs.extend(bundesliga_clubs)

# 2. Bundesliga (18 clubs)
bundesliga2_names = [
    "Schalke", "Hamburg", "Hertha Berlin", "Hannover", "Kaiserslautern", "St. Pauli",
    "Fortuna Dusseldorf", "Paderborn", "Karlsruher", "Nurnberg", "Greuther Furth", "Braunschweig",
    "Hansa Rostock", "Magdeburg", "Elversberg", "Wehen Wiesbaden", "Osnabrueck", "Regensburg"
]

for i, name in enumerate(bundesliga2_names, start=419):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 21,
        "country": "Germany",
        "reputation": 68 + (i % 6),
        "budget": 55000000 + (i * 1800000)
    })

# 3. Liga and Regionalliga (32 clubs)
german_lower = [
    "Munich 1860", "Dresden", "Saarbrucken", "Ingolstadt", "Unterhaching", "Mannheim",
    "Verl", "Viktoria Koln", "Duisburg", "Essen", "Aachen", "Rostock B", "Lubeck",
    "Energie Cottbus", "Sandhausen", "Arminia Bielefeld", "Wuppertaler", "Preussen Munster",
    "Bayern II", "Dortmund II", "Stuttgart II", "Wolfsburg II", "Frankfurt II", "Hamburg II",
    "Schalke II", "Koln II", "Bremen II", "Hannover II", "Hoffenheim II", "Leverkusen II",
    "Freiburg II", "Monchengladbach II"
]

for i, name in enumerate(german_lower, start=437):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 22,
        "country": "Germany",
        "reputation": 54 + (i % 5),
        "budget": 12000000 + (i * 350000)
    })

# Serie A (20 clubs)
seriea_clubs = [
    {"id": 501, "name": "AC Milan", "league_id": 30, "country": "Italy", "reputation": 91, "budget": 420000000},
    {"id": 502, "name": "Inter Milan", "league_id": 30, "country": "Italy", "reputation": 92, "budget": 440000000},
    {"id": 503, "name": "Napoli", "league_id": 30, "country": "Italy", "reputation": 89, "budget": 350000000},
    {"id": 504, "name": "AS Roma", "league_id": 30, "country": "Italy", "reputation": 86, "budget": 300000000},
    {"id": 505, "name": "Juventus", "league_id": 30, "country": "Italy", "reputation": 93, "budget": 450000000},
    {"id": 506, "name": "Lazio", "league_id": 30, "country": "Italy", "reputation": 84, "budget": 260000000},
    {"id": 507, "name": "Atalanta", "league_id": 30, "country": "Italy", "reputation": 85, "budget": 280000000},
    {"id": 508, "name": "Fiorentina", "league_id": 30, "country": "Italy", "reputation": 83, "budget": 240000000},
    {"id": 509, "name": "Bologna", "league_id": 30, "country": "Italy", "reputation": 78, "budget": 170000000},
    {"id": 510, "name": "Torino", "league_id": 30, "country": "Italy", "reputation": 77, "budget": 160000000},
    {"id": 511, "name": "Udinese", "league_id": 30, "country": "Italy", "reputation": 76, "budget": 145000000},
    {"id": 512, "name": "Monza", "league_id": 30, "country": "Italy", "reputation": 74, "budget": 130000000},
    {"id": 513, "name": "Hellas Verona", "league_id": 30, "country": "Italy", "reputation": 73, "budget": 120000000},
    {"id": 514, "name": "Sassuolo", "league_id": 30, "country": "Italy", "reputation": 75, "budget": 135000000},
    {"id": 515, "name": "Lecce", "league_id": 30, "country": "Italy", "reputation": 72, "budget": 110000000},
    {"id": 516, "name": "Cagliari", "league_id": 30, "country": "Italy", "reputation": 73, "budget": 115000000},
    {"id": 517, "name": "Empoli", "league_id": 30, "country": "Italy", "reputation": 72, "budget": 105000000},
    {"id": 518, "name": "Salernitana", "league_id": 30, "country": "Italy", "reputation": 71, "budget": 100000000},
    {"id": 519, "name": "Frosinone", "league_id": 30, "country": "Italy", "reputation": 70, "budget": 95000000},
    {"id": 520, "name": "Genoa", "league_id": 30, "country": "Italy", "reputation": 74, "budget": 125000000},
]
clubs.extend(seriea_clubs)

# Serie B (20 clubs)
serieb_names = [
    "Parma", "Como", "Venezia", "Palermo", "Sampdoria", "Brescia", "Cremonese",
    "Bari", "Catanzaro", "Spezia", "Cittadella", "Modena", "Ternana", "Pisa",
    "Reggiana", "Cosenza", "Sudtirol", "Feralpisalo", "Ascoli", "Lecco"
]

for i, name in enumerate(serieb_names, start=521):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 31,
        "country": "Italy",
        "reputation": 66 + (i % 6),
        "budget": 50000000 + (i * 1600000)
    })

# Serie C and lower (30 clubs)
italian_lower = [
    "Novara", "Pro Vercelli", "Alessandria", "Triestina", "Vicenza", "Padova",
    "Avellino", "Benevento", "Reggina", "Catania", "Messina", "Pescara",
    "Ancona", "Perugia", "Cesena", "Rimini", "Carrarese", "Juventus U23",
    "Atalanta U23", "Milan Primavera", "Inter Primavera", "Roma Primavera", "Napoli Primavera",
    "Lazio Primavera", "Fiorentina Primavera", "Bologna Primavera", "Torino Primavera",
    "Udinese Primavera", "Sassuolo Primavera", "Genoa Primavera"
]

for i, name in enumerate(italian_lower, start=541):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 32,
        "country": "Italy",
        "reputation": 52 + (i % 5),
        "budget": 10000000 + (i * 280000)
    })

# Ligue 1 (18 clubs)
ligue1_clubs = [
    {"id": 601, "name": "Paris Saint-Germain", "league_id": 40, "country": "France", "reputation": 94, "budget": 520000000},
    {"id": 602, "name": "Marseille", "league_id": 40, "country": "France", "reputation": 84, "budget": 260000000},
    {"id": 603, "name": "Monaco", "league_id": 40, "country": "France", "reputation": 85, "budget": 280000000},
    {"id": 604, "name": "Lyon", "league_id": 40, "country": "France", "reputation": 83, "budget": 250000000},
    {"id": 605, "name": "Lille", "league_id": 40, "country": "France", "reputation": 82, "budget": 230000000},
    {"id": 606, "name": "Nice", "league_id": 40, "country": "France", "reputation": 79, "budget": 190000000},
    {"id": 607, "name": "Lens", "league_id": 40, "country": "France", "reputation": 78, "budget": 170000000},
    {"id": 608, "name": "Rennes", "league_id": 40, "country": "France", "reputation": 80, "budget": 200000000},
    {"id": 609, "name": "Brest", "league_id": 40, "country": "France", "reputation": 75, "budget": 135000000},
    {"id": 610, "name": "Reims", "league_id": 40, "country": "France", "reputation": 74, "budget": 125000000},
    {"id": 611, "name": "Montpellier", "league_id": 40, "country": "France", "reputation": 76, "budget": 145000000},
    {"id": 612, "name": "Strasbourg", "league_id": 40, "country": "France", "reputation": 74, "budget": 130000000},
    {"id": 613, "name": "Nantes", "league_id": 40, "country": "France", "reputation": 75, "budget": 138000000},
    {"id": 614, "name": "Toulouse", "league_id": 40, "country": "France", "reputation": 73, "budget": 118000000},
    {"id": 615, "name": "Le Havre", "league_id": 40, "country": "France", "reputation": 72, "budget": 110000000},
    {"id": 616, "name": "Clermont", "league_id": 40, "country": "France", "reputation": 71, "budget": 105000000},
    {"id": 617, "name": "Lorient", "league_id": 40, "country": "France", "reputation": 72, "budget": 108000000},
    {"id": 618, "name": "Metz", "league_id": 40, "country": "France", "reputation": 72, "budget": 112000000},
]
clubs.extend(ligue1_clubs)

# Ligue 2 (20 clubs)
ligue2_names = [
    "Bordeaux", "Saint-Etienne", "Auxerre", "Caen", "Angers", "Troyes",
    "Bastia", "Ajaccio", "Amiens", "Laval", "Rodez", "Grenoble",
    "Paris FC", "Dunkerque", "Pau", "Quevilly", "Guingamp", "Sochaux",
    "Valenciennes", "Annecy"
]

for i, name in enumerate(ligue2_names, start=619):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 41,
        "country": "France",
        "reputation": 66 + (i % 6),
        "budget": 45000000 + (i * 1400000)
    })

# National and lower (22 clubs)
french_lower = [
    "Chateauroux", "Niort", "Cholet", "Versailles", "Dijon", "Le Mans",
    "Nancy", "Red Star", "Villefranche", "Boulogne", "Sedan", "Orleans",
    "PSG B", "Lyon B", "Monaco B", "Marseille B", "Lille B", "Nice B",
    "Rennes B", "Lens B", "Strasbourg B", "Montpellier B"
]

for i, name in enumerate(french_lower, start=639):
    clubs.append({
        "id": i,
        "name": name,
        "league_id": 42,
        "country": "France",
        "reputation": 50 + (i % 5),
        "budget": 8000000 + (i * 250000)
    })

# MLS - Add USA club
clubs.append({"id": 101, "name": "Inter Miami", "league_id": 50, "country": "USA", "reputation": 78, "budget": 180000000})

# Saudi Pro League - Add Saudi club
clubs.append({"id": 201, "name": "Al Nassr", "league_id": 60, "country": "Saudi Arabia", "reputation": 76, "budget": 400000000})

print(f"Generated {len(clubs)} clubs")

with open('/home/claude/football_career_simulator/data/clubs.json', 'w') as f:
    json.dump(clubs, f, indent=2)
