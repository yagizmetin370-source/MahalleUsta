import json
import random

# Generate 1000+ realistic players
players = []
player_id = 1

# Top tier players (90-95 overall)
elite_players = [
    ("Kylian Mbappé", 25, 91, 95, "ST", "France", 301, 180000000, 900000),
    ("Erling Haaland", 23, 91, 95, "ST", "Norway", 1, 175000000, 850000),
    ("Lionel Messi", 36, 91, 91, "RW", "Argentina", 101, 45000000, 800000),
    ("Kevin De Bruyne", 32, 91, 91, "CM", "Belgium", 1, 85000000, 700000),
    ("Robert Lewandowski", 35, 90, 90, "ST", "Poland", 302, 50000000, 700000),
    ("Harry Kane", 30, 89, 89, "ST", "England", 401, 95000000, 600000),
    ("Mohamed Salah", 31, 89, 89, "RW", "Egypt", 2, 90000000, 650000),
    ("Vinicius Junior", 23, 89, 94, "LW", "Brazil", 301, 150000000, 650000),
    ("Rodri", 27, 89, 90, "CDM", "Spain", 1, 110000000, 500000),
    ("Virgil van Dijk", 32, 89, 89, "CB", "Netherlands", 2, 70000000, 550000),
]

for name, age, overall, potential, pos, nation, club, value, wage in elite_players:
    players.append({
        "id": player_id,
        "name": name,
        "age": age,
        "overall": overall,
        "potential": potential,
        "position": pos,
        "nationality": nation,
        "club_id": club,
        "value": value,
        "wage": wage,
        "contract_years": random.randint(2, 5)
    })
    player_id += 1

# Generate Premier League players (200 players)
pl_clubs = list(range(1, 21))
pl_first_names = ["James", "Jack", "Harry", "Ben", "Luke", "Mason", "Phil", "Raheem", "Marcus", "Bukayo", 
                  "Declan", "Cole", "Alexander", "Callum", "Reece", "Trent", "Jordan", "Aaron", "Gabriel", "Darwin",
                  "Luis", "Alexis", "Bruno", "Casemiro", "Son", "Maddison", "Richarlison", "Saka", "Foden", "Grealish"]
pl_last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez",
                 "Anderson", "Taylor", "Thomas", "Moore", "Jackson", "Martin", "Lee", "White", "Harris", "Clark",
                 "Lewis", "Walker", "Hall", "Allen", "Young", "King", "Wright", "Lopez", "Hill", "Green"]

positions = ["GK", "CB", "CB", "LB", "RB", "CDM", "CM", "CM", "CAM", "LW", "RW", "ST"]

for i in range(200):
    age = random.randint(18, 35)
    overall = random.randint(72, 88)
    potential = min(94, overall + random.randint(0, 8))
    
    players.append({
        "id": player_id,
        "name": f"{random.choice(pl_first_names)} {random.choice(pl_last_names)}",
        "age": age,
        "overall": overall,
        "potential": potential,
        "position": random.choice(positions),
        "nationality": random.choice(["England", "Brazil", "Argentina", "France", "Spain", "Portugal", "Netherlands", "Belgium"]),
        "club_id": random.choice(pl_clubs),
        "value": overall * 1000000 + random.randint(0, 20000000),
        "wage": overall * 10000,
        "contract_years": random.randint(1, 5)
    })
    player_id += 1

# Generate La Liga players (200 players)
laliga_clubs = list(range(301, 321))
spanish_first_names = ["Carlos", "Miguel", "Juan", "David", "Alejandro", "Daniel", "Pablo", "Sergio", "Javier", "Alvaro",
                       "Marco", "Adrian", "Raul", "Diego", "Fernando", "Antonio", "Manuel", "Jorge", "Luis", "Angel"]
spanish_last_names = ["García", "Rodríguez", "González", "Fernández", "López", "Martínez", "Sánchez", "Pérez", "Gómez", "Martín",
                      "Jiménez", "Ruiz", "Hernández", "Díaz", "Moreno", "Muñoz", "Álvarez", "Romero", "Alonso", "Gutiérrez"]

for i in range(200):
    age = random.randint(18, 35)
    overall = random.randint(71, 87)
    potential = min(93, overall + random.randint(0, 8))
    
    players.append({
        "id": player_id,
        "name": f"{random.choice(spanish_first_names)} {random.choice(spanish_last_names)}",
        "age": age,
        "overall": overall,
        "potential": potential,
        "position": random.choice(positions),
        "nationality": random.choice(["Spain", "Brazil", "Argentina", "Uruguay", "France", "Portugal", "Colombia", "Mexico"]),
        "club_id": random.choice(laliga_clubs),
        "value": overall * 900000 + random.randint(0, 15000000),
        "wage": overall * 9000,
        "contract_years": random.randint(1, 5)
    })
    player_id += 1

# Generate Bundesliga players (180 players)
bundesliga_clubs = list(range(401, 419))
german_first_names = ["Leon", "Thomas", "Joshua", "Kai", "Florian", "Marco", "Jonas", "David", "Niklas", "Timo",
                      "Serge", "Leroy", "Julian", "Marcel", "Kevin", "Mats", "Manuel", "Jamal", "Lukas", "Matthias"]
german_last_names = ["Müller", "Schmidt", "Schneider", "Fischer", "Weber", "Meyer", "Wagner", "Becker", "Schulz", "Hoffmann",
                    "Koch", "Bauer", "Richter", "Klein", "Wolf", "Schröder", "Neumann", "Schwarz", "Zimmermann", "Braun"]

for i in range(180):
    age = random.randint(18, 34)
    overall = random.randint(70, 86)
    potential = min(92, overall + random.randint(0, 8))
    
    players.append({
        "id": player_id,
        "name": f"{random.choice(german_first_names)} {random.choice(german_last_names)}",
        "age": age,
        "overall": overall,
        "potential": potential,
        "position": random.choice(positions),
        "nationality": random.choice(["Germany", "France", "Netherlands", "Austria", "Switzerland", "Poland", "Czech Republic", "Denmark"]),
        "club_id": random.choice(bundesliga_clubs),
        "value": overall * 850000 + random.randint(0, 12000000),
        "wage": overall * 8500,
        "contract_years": random.randint(1, 5)
    })
    player_id += 1

# Generate Serie A players (200 players)
seriea_clubs = list(range(501, 521))
italian_first_names = ["Marco", "Luca", "Andrea", "Alessandro", "Matteo", "Lorenzo", "Davide", "Federico", "Simone", "Nicolo",
                       "Francesco", "Giuseppe", "Antonio", "Riccardo", "Stefano", "Mattia", "Filippo", "Giovanni", "Pietro", "Gabriele"]
italian_last_names = ["Rossi", "Russo", "Ferrari", "Esposito", "Bianchi", "Romano", "Colombo", "Ricci", "Marino", "Greco",
                     "Bruno", "Gallo", "Conti", "De Luca", "Costa", "Giordano", "Mancini", "Rizzo", "Lombardi", "Moretti"]

for i in range(200):
    age = random.randint(18, 35)
    overall = random.randint(70, 87)
    potential = min(92, overall + random.randint(0, 8))
    
    players.append({
        "id": player_id,
        "name": f"{random.choice(italian_first_names)} {random.choice(italian_last_names)}",
        "age": age,
        "overall": overall,
        "potential": potential,
        "position": random.choice(positions),
        "nationality": random.choice(["Italy", "Argentina", "Brazil", "France", "Spain", "Croatia", "Serbia", "Belgium"]),
        "club_id": random.choice(seriea_clubs),
        "value": overall * 800000 + random.randint(0, 10000000),
        "wage": overall * 8000,
        "contract_years": random.randint(1, 5)
    })
    player_id += 1

# Generate Ligue 1 players (150 players)
ligue1_clubs = list(range(601, 619))
french_first_names = ["Antoine", "Lucas", "Alexandre", "Florian", "Maxime", "Thomas", "Hugo", "Mathieu", "Romain", "Clement",
                      "Jordan", "Alexis", "Kevin", "Yann", "Morgan", "Benjamin", "Adrien", "Theo", "Olivier", "Jonathan"]
french_last_names = ["Martin", "Bernard", "Dubois", "Thomas", "Robert", "Richard", "Petit", "Durand", "Leroy", "Moreau",
                    "Simon", "Laurent", "Lefebvre", "Michel", "Garcia", "David", "Bertrand", "Roux", "Vincent", "Fournier"]

for i in range(150):
    age = random.randint(18, 34)
    overall = random.randint(69, 85)
    potential = min(91, overall + random.randint(0, 8))
    
    players.append({
        "id": player_id,
        "name": f"{random.choice(french_first_names)} {random.choice(french_last_names)}",
        "age": age,
        "overall": overall,
        "potential": potential,
        "position": random.choice(positions),
        "nationality": random.choice(["France", "Senegal", "Algeria", "Morocco", "Ivory Coast", "Brazil", "Argentina", "Portugal"]),
        "club_id": random.choice(ligue1_clubs),
        "value": overall * 750000 + random.randint(0, 8000000),
        "wage": overall * 7500,
        "contract_years": random.randint(1, 5)
    })
    player_id += 1

# Generate additional lower league players to reach 1000+
lower_clubs = list(range(21, 101)) + list(range(321, 401)) + list(range(419, 501)) + list(range(521, 601)) + list(range(619, 651))

for i in range(100):
    age = random.randint(18, 32)
    overall = random.randint(65, 78)
    potential = min(85, overall + random.randint(0, 10))
    
    all_first = pl_first_names + spanish_first_names + german_first_names + italian_first_names + french_first_names
    all_last = pl_last_names + spanish_last_names + german_last_names + italian_last_names + french_last_names
    
    players.append({
        "id": player_id,
        "name": f"{random.choice(all_first)} {random.choice(all_last)}",
        "age": age,
        "overall": overall,
        "potential": potential,
        "position": random.choice(positions),
        "nationality": random.choice(["England", "Spain", "Germany", "Italy", "France", "Brazil", "Argentina", "Portugal", "Netherlands", "Belgium"]),
        "club_id": random.choice(lower_clubs),
        "value": overall * 500000,
        "wage": overall * 5000,
        "contract_years": random.randint(1, 4)
    })
    player_id += 1

print(f"Generated {len(players)} players")

with open('/home/claude/football_career_simulator/data/players.json', 'w') as f:
    json.dump(players, f, indent=2)
