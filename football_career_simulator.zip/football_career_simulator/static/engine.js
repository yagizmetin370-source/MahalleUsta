// Match Engine
class MatchEngine {
    constructor() {
        this.positions = {
            'GK': { defensive: 100, attacking: 10 },
            'CB': { defensive: 90, attacking: 20 },
            'LB': { defensive: 75, attacking: 40 },
            'RB': { defensive: 75, attacking: 40 },
            'CDM': { defensive: 70, attacking: 45 },
            'CM': { defensive: 55, attacking: 60 },
            'CAM': { defensive: 40, attacking: 75 },
            'LW': { defensive: 30, attacking: 85 },
            'RW': { defensive: 30, attacking: 85 },
            'ST': { defensive: 20, attacking: 95 }
        };
    }
    
    simulateMatch(homeClub, awayClub, player, playerClub) {
        const homeStrength = this.calculateTeamStrength(homeClub);
        const awayStrength = this.calculateTeamStrength(awayClub);
        
        // Home advantage
        const homeBonus = homeStrength * 0.1;
        const adjustedHome = homeStrength + homeBonus;
        
        // Calculate goals
        const homeGoals = this.calculateGoals(adjustedHome, awayStrength);
        const awayGoals = this.calculateGoals(awayStrength, adjustedHome);
        
        // Player performance
        const playerPerformance = this.calculatePlayerPerformance(player, playerClub, homeClub, awayClub);
        
        return {
            home: homeClub.name,
            away: awayClub.name,
            home_score: homeGoals,
            away_score: awayGoals,
            player_rating: playerPerformance.rating,
            player_goals: playerPerformance.goals,
            player_assists: playerPerformance.assists,
            player_motm: playerPerformance.motm
        };
    }
    
    calculateTeamStrength(club) {
        return club.reputation || 75;
    }
    
    calculateGoals(attackStrength, defenseStrength) {
        const ratio = attackStrength / defenseStrength;
        const baseGoals = ratio * 1.5;
        const randomFactor = Math.random() * 1.5;
        const goals = Math.floor(baseGoals + randomFactor);
        return Math.max(0, Math.min(6, goals)); // Between 0 and 6
    }
    
    calculatePlayerPerformance(player, playerClub, homeClub, awayClub) {
        const isHome = playerClub.id === homeClub.id;
        const opponentClub = isHome ? awayClub : homeClub;
        
        // Base rating from overall
        let rating = player.overall / 10;
        
        // Random variance
        rating += (Math.random() - 0.5) * 2;
        
        // Position bonus
        const positionData = this.positions[player.position] || { attacking: 50, defensive: 50 };
        
        // Goals and assists
        let goals = 0;
        let assists = 0;
        
        // Attacking positions more likely to score
        const scoringChance = (positionData.attacking / 100) * (player.attributes.shooting / 100);
        if (Math.random() < scoringChance * 0.3) {
            goals = Math.floor(Math.random() * 2) + 1;
            rating += goals * 0.5;
        }
        
        // Assists
        const assistChance = (player.attributes.passing / 100) * 0.25;
        if (Math.random() < assistChance) {
            assists = Math.floor(Math.random() * 2) + 1;
            rating += assists * 0.3;
        }
        
        // Clamp rating between 4.0 and 10.0
        rating = Math.max(4.0, Math.min(10.0, rating));
        rating = parseFloat(rating.toFixed(1));
        
        // Man of the match (rating > 8.5)
        const motm = rating >= 8.5;
        
        return {
            rating,
            goals,
            assists,
            motm
        };
    }
}

// Player Growth System
class PlayerGrowth {
    constructor() {
        this.growthCurves = {
            'early': { peak: 25, decline: 30 },
            'normal': { peak: 27, decline: 31 },
            'late': { peak: 29, decline: 33 }
        };
    }
    
    calculateGrowth(player) {
        const age = player.age;
        const potential = player.potential;
        const current = player.overall;
        
        if (current >= potential) return 0;
        
        // Growth rate based on age
        let growthRate = 1.0;
        if (age < 22) {
            growthRate = 1.5;
        } else if (age < 25) {
            growthRate = 1.2;
        } else if (age < 28) {
            growthRate = 1.0;
        } else if (age < 30) {
            growthRate = 0.7;
        } else {
            growthRate = 0.4;
        }
        
        // Random growth
        const growth = Math.random() * growthRate;
        
        // Ensure doesn't exceed potential
        return Math.min(growth, potential - current);
    }
    
    trainAttribute(player, attribute) {
        if (!player.attributes[attribute]) return 0;
        
        const current = player.attributes[attribute];
        const potential = player.potential;
        
        // Training improvement
        const improvement = Math.floor(Math.random() * 3) + 1;
        const newValue = Math.min(99, current + improvement);
        
        player.attributes[attribute] = newValue;
        
        // Recalculate overall
        this.recalculateOverall(player);
        
        return improvement;
    }
    
    recalculateOverall(player) {
        const attrs = player.attributes;
        const position = player.position;
        
        let total = 0;
        let count = 0;
        
        // Weight attributes based on position
        const weights = this.getPositionWeights(position);
        
        for (const [attr, weight] of Object.entries(weights)) {
            if (attrs[attr]) {
                total += attrs[attr] * weight;
                count += weight;
            }
        }
        
        player.overall = Math.min(player.potential, Math.floor(total / count));
    }
    
    getPositionWeights(position) {
        const weights = {
            'GK': { pace: 0.5, shooting: 0.1, passing: 0.8, dribbling: 0.3, defending: 1.5, physical: 1.0 },
            'CB': { pace: 0.7, shooting: 0.3, passing: 0.7, dribbling: 0.5, defending: 1.8, physical: 1.5 },
            'LB': { pace: 1.2, shooting: 0.4, passing: 1.0, dribbling: 1.0, defending: 1.3, physical: 1.0 },
            'RB': { pace: 1.2, shooting: 0.4, passing: 1.0, dribbling: 1.0, defending: 1.3, physical: 1.0 },
            'CDM': { pace: 0.8, shooting: 0.6, passing: 1.2, dribbling: 0.9, defending: 1.4, physical: 1.2 },
            'CM': { pace: 0.9, shooting: 0.9, passing: 1.5, dribbling: 1.2, defending: 1.0, physical: 1.0 },
            'CAM': { pace: 1.0, shooting: 1.4, passing: 1.5, dribbling: 1.5, defending: 0.5, physical: 0.7 },
            'LW': { pace: 1.5, shooting: 1.3, passing: 1.1, dribbling: 1.6, defending: 0.4, physical: 0.7 },
            'RW': { pace: 1.5, shooting: 1.3, passing: 1.1, dribbling: 1.6, defending: 0.4, physical: 0.7 },
            'ST': { pace: 1.3, shooting: 1.8, passing: 0.8, dribbling: 1.2, defending: 0.3, physical: 1.1 }
        };
        
        return weights[position] || weights['CM'];
    }
}

// Transfer System
class TransferSystem {
    constructor() {
        this.transferWindow = { summer: [20, 30], winter: [1, 5] };
    }
    
    generateTransferOffer(player, clubs) {
        // Filter clubs based on player value and reputation
        const interestedClubs = clubs.filter(club => {
            const clubBudget = club.budget || 100000000;
            const canAfford = clubBudget > player.value * 0.5;
            const reputationMatch = Math.abs(club.reputation - player.overall) < 15;
            return canAfford && reputationMatch && club.id !== player.club_id;
        });
        
        if (interestedClubs.length === 0) return null;
        
        const offeringClub = interestedClubs[Math.floor(Math.random() * interestedClubs.length)];
        
        // Calculate offer
        const transferFee = player.value * (0.8 + Math.random() * 0.4);
        const wage = player.wage * (1.1 + Math.random() * 0.3);
        const contractLength = Math.floor(Math.random() * 3) + 2;
        
        return {
            club: offeringClub,
            transfer_fee: Math.floor(transferFee),
            wage: Math.floor(wage),
            contract_years: contractLength,
            bonus: Math.floor(transferFee * 0.1)
        };
    }
}

// Season Management
class SeasonManager {
    constructor() {
        this.weeksInSeason = 38;
    }
    
    checkSeasonEnd(currentWeek) {
        return currentWeek > this.weeksInSeason;
    }
    
    advanceSeason(gameState) {
        // Award trophies
        // Update player stats
        // Age players
        gameState.player.age++;
        
        // Reset season stats
        gameState.player.season_matches = 0;
        gameState.player.season_goals = 0;
        gameState.player.season_assists = 0;
        gameState.player.season_rating_total = 0;
        
        // Decrease contract
        if (gameState.player.contract_years > 0) {
            gameState.player.contract_years--;
        }
        
        // Next season
        const currentYear = parseInt(gameState.currentSeason.split('/')[0]);
        gameState.currentSeason = `${currentYear + 1}/${(currentYear + 2).toString().slice(2)}`;
        gameState.currentWeek = 1;
        
        return gameState;
    }
}

// Injury System
class InjurySystem {
    constructor() {
        this.injuryTypes = [
            { name: 'Muscle Strain', weeks: 2 },
            { name: 'Sprained Ankle', weeks: 3 },
            { name: 'Hamstring', weeks: 4 },
            { name: 'Knee Injury', weeks: 6 },
            { name: 'Broken Bone', weeks: 12 }
        ];
    }
    
    checkInjury(player, matchIntensity = 1.0) {
        const injuryChance = 0.05 * matchIntensity;
        
        if (Math.random() < injuryChance) {
            const injury = this.injuryTypes[Math.floor(Math.random() * this.injuryTypes.length)];
            return {
                injured: true,
                injury: injury.name,
                weeks_out: injury.weeks
            };
        }
        
        return { injured: false };
    }
}

// Export instances
const matchEngine = new MatchEngine();
const playerGrowth = new PlayerGrowth();
const transferSystem = new TransferSystem();
const seasonManager = new SeasonManager();
const injurySystem = new InjurySystem();
