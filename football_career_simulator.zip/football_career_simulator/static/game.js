// Global Game State
let gameState = {
    player: null,
    currentSeason: "2024/25",
    currentWeek: 1,
    clubs: [],
    players: [],
    leagues: [],
    tournaments: [],
    matches: [],
    careerHistory: [],
    newsItems: []
};

// Initialize Game
async function initGame() {
    showLoading(true);
    try {
        await loadGameData();
        showLoading(false);
    } catch (error) {
        console.error("Error loading game data:", error);
        showToast("Error loading game data", "error");
        showLoading(false);
    }
}

// Load all game data
async function loadGameData() {
    try {
        const response = await fetch('/api/game_data');
        const data = await response.json();
        gameState.clubs = data.clubs || [];
        gameState.players = data.players || [];
        gameState.leagues = data.leagues || [];
        gameState.tournaments = data.tournaments || [];
        
        // Update UI
        document.getElementById('total-players').textContent = gameState.players.length + '+';
        document.getElementById('total-clubs').textContent = gameState.clubs.length + '+';
    } catch (error) {
        console.error("Error loading game data:", error);
    }
}

// Create new career
async function createCareer() {
    const name = document.getElementById('player-name').value.trim();
    const nationality = document.getElementById('player-nationality').value;
    const position = document.getElementById('player-position').value;
    let clubId = document.getElementById('starting-club').value;
    
    if (!name) {
        showToast("Please enter a player name", "warning");
        return;
    }
    
    showLoading(true);
    
    try {
        // Random club if selected
        if (clubId === 'random') {
            const randomClubs = gameState.clubs.filter(c => c.reputation >= 70 && c.reputation <= 85);
            clubId = randomClubs[Math.floor(Math.random() * randomClubs.length)].id;
        }
        
        const response = await fetch('/api/new_career', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name,
                nationality,
                position,
                club_id: parseInt(clubId)
            })
        });
        
        const data = await response.json();
        if (data.success) {
            gameState.player = data.player;
            initializeGameScreen();
            showScreen('game-screen');
            showToast("Career started successfully!", "success");
            addNews(`Welcome ${name}! Your football career begins now.`);
        } else {
            showToast(data.message || "Error creating career", "error");
        }
    } catch (error) {
        console.error("Error creating career:", error);
        showToast("Error creating career", "error");
    }
    
    showLoading(false);
}

// Initialize game screen with player data
function initializeGameScreen() {
    if (!gameState.player) return;
    
    const player = gameState.player;
    const club = gameState.clubs.find(c => c.id === player.club_id);
    
    // Update top bar
    document.getElementById('avatar-initial').textContent = player.name.charAt(0);
    document.getElementById('player-name-display').textContent = player.name;
    document.getElementById('player-club-display').textContent = club ? club.name : 'Free Agent';
    document.getElementById('current-season').textContent = gameState.currentSeason;
    document.getElementById('current-week').textContent = gameState.currentWeek;
    document.getElementById('player-ovr').textContent = player.overall;
    document.getElementById('player-goals').textContent = player.season_goals || 0;
    document.getElementById('player-assists').textContent = player.season_assists || 0;
    
    // Update player card
    updatePlayerCard();
    
    // Update season stats
    updateSeasonStats();
    
    // Generate next match
    generateNextMatch();
    
    // Update league table
    updateLeagueTable();
}

// Update player card
function updatePlayerCard() {
    const player = gameState.player;
    if (!player) return;
    
    document.getElementById('card-rating').textContent = player.overall;
    document.getElementById('card-position').textContent = player.position;
    document.getElementById('card-name').textContent = player.name.toUpperCase();
    
    // Update attributes
    document.getElementById('stat-pace').textContent = player.attributes.pace || 70;
    document.getElementById('stat-shooting').textContent = player.attributes.shooting || 70;
    document.getElementById('stat-passing').textContent = player.attributes.passing || 70;
    document.getElementById('stat-dribbling').textContent = player.attributes.dribbling || 70;
    document.getElementById('stat-defending').textContent = player.attributes.defending || 40;
    document.getElementById('stat-physical').textContent = player.attributes.physical || 70;
}

// Update season stats
function updateSeasonStats() {
    const player = gameState.player;
    if (!player) return;
    
    document.getElementById('stats-matches').textContent = player.season_matches || 0;
    document.getElementById('stats-goals').textContent = player.season_goals || 0;
    document.getElementById('stats-assists').textContent = player.season_assists || 0;
    
    const avgRating = player.season_matches > 0 
        ? (player.season_rating_total / player.season_matches).toFixed(1)
        : '-';
    document.getElementById('stats-rating').textContent = avgRating;
    
    // Career stats
    document.getElementById('career-matches').textContent = player.career_matches || 0;
    document.getElementById('career-goals').textContent = player.career_goals || 0;
    document.getElementById('career-assists').textContent = player.career_assists || 0;
    document.getElementById('career-trophies').textContent = player.career_trophies || 0;
    
    // Contract info
    document.getElementById('contract-wage').textContent = '£' + formatNumber(player.wage || 0);
    document.getElementById('contract-years').textContent = (player.contract_years || 0) + ' years';
    document.getElementById('player-value').textContent = '£' + formatNumber(player.value || 0);
}

// Generate next match
function generateNextMatch() {
    const player = gameState.player;
    if (!player) return;
    
    const club = gameState.clubs.find(c => c.id === player.club_id);
    if (!club) return;
    
    const leagueClubs = gameState.clubs.filter(c => c.league_id === club.league_id && c.id !== club.id);
    const opponent = leagueClubs[Math.floor(Math.random() * leagueClubs.length)];
    
    document.getElementById('next-home').textContent = club.name;
    document.getElementById('next-away').textContent = opponent.name;
    document.getElementById('next-competition').textContent = 'League';
    document.getElementById('next-week').textContent = gameState.currentWeek;
}

// Play match
async function playMatch() {
    showLoading(true);
    
    try {
        const response = await fetch('/api/sim_match', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                player_id: gameState.player.id,
                week: gameState.currentWeek
            })
        });
        
        const result = await response.json();
        if (result.success) {
            showMatchResult(result.match);
            gameState.player = result.player;
            gameState.currentWeek++;
            document.getElementById('current-week').textContent = gameState.currentWeek;
            updatePlayerCard();
            updateSeasonStats();
            generateNextMatch();
            addNews(`Match played: ${result.match.home} ${result.match.home_score} - ${result.match.away_score} ${result.match.away}. Your rating: ${result.match.player_rating}`);
        }
    } catch (error) {
        console.error("Error playing match:", error);
        showToast("Error playing match", "error");
    }
    
    showLoading(false);
}

// Show match result
function showMatchResult(match) {
    const message = `
        ${match.home} ${match.home_score} - ${match.away_score} ${match.away}
        Your Performance: ${match.player_rating} rating
        Goals: ${match.player_goals || 0} | Assists: ${match.player_assists || 0}
    `;
    showToast(message, match.home_score > match.away_score ? "success" : "warning");
}

// Training
async function train(attribute) {
    if (!gameState.player) return;
    
    showLoading(true);
    
    try {
        const response = await fetch('/api/train', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                player_id: gameState.player.id,
                attribute
            })
        });
        
        const result = await response.json();
        if (result.success) {
            gameState.player = result.player;
            gameState.currentWeek++;
            document.getElementById('current-week').textContent = gameState.currentWeek;
            updatePlayerCard();
            showToast(`${attribute.toUpperCase()} training completed! +${result.improvement}`, "success");
            addNews(`Completed ${attribute} training session.`);
        }
    } catch (error) {
        console.error("Error training:", error);
        showToast("Error during training", "error");
    }
    
    showLoading(false);
}

// Advance week (simulate)
async function advanceWeek() {
    if (!gameState.player) return;
    
    showLoading(true);
    
    try {
        // Simulate match and advance
        await playMatch();
    } catch (error) {
        console.error("Error advancing week:", error);
        showToast("Error advancing week", "error");
    }
    
    showLoading(false);
}

// Update league table
function updateLeagueTable() {
    const player = gameState.player;
    if (!player) return;
    
    const club = gameState.clubs.find(c => c.id === player.club_id);
    if (!club) return;
    
    const leagueClubs = gameState.clubs.filter(c => c.league_id === club.league_id)
        .sort((a, b) => (b.reputation || 0) - (a.reputation || 0))
        .slice(0, 20);
    
    const tableHTML = `
        <table>
            <thead>
                <tr>
                    <th>Pos</th>
                    <th>Club</th>
                    <th>Pts</th>
                    <th>W</th>
                    <th>D</th>
                    <th>L</th>
                    <th>GD</th>
                </tr>
            </thead>
            <tbody>
                ${leagueClubs.map((c, i) => {
                    const points = 38 - i * 2 + Math.floor(Math.random() * 10);
                    const wins = Math.floor(points / 3);
                    const draws = points % 3;
                    const losses = 14 - wins - draws;
                    const gd = wins * 2 - losses * 2;
                    
                    return `
                        <tr style="${c.id === player.club_id ? 'background: rgba(0, 217, 255, 0.1);' : ''}">
                            <td>${i + 1}</td>
                            <td>${c.name}</td>
                            <td><strong>${points}</strong></td>
                            <td>${wins}</td>
                            <td>${draws}</td>
                            <td>${losses}</td>
                            <td>${gd > 0 ? '+' : ''}${gd}</td>
                        </tr>
                    `;
                }).join('')}
            </tbody>
        </table>
    `;
    
    document.getElementById('league-table').innerHTML = tableHTML;
}

// Save game
async function saveGame() {
    showLoading(true);
    
    try {
        const response = await fetch('/api/save_career', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ gameState })
        });
        
        const result = await response.json();
        if (result.success) {
            showToast("Game saved successfully!", "success");
        }
    } catch (error) {
        console.error("Error saving game:", error);
        showToast("Error saving game", "error");
    }
    
    showLoading(false);
}

// Load career
async function loadCareer() {
    showLoading(true);
    
    try {
        const response = await fetch('/api/load_career');
        const result = await response.json();
        
        if (result.success && result.gameState) {
            gameState = result.gameState;
            initializeGameScreen();
            showScreen('game-screen');
            showToast("Career loaded successfully!", "success");
        } else {
            showToast("No saved career found", "warning");
        }
    } catch (error) {
        console.error("Error loading career:", error);
        showToast("Error loading career", "error");
    }
    
    showLoading(false);
}

// UI Functions
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
}

function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    document.getElementById(`tab-${tabName}`).classList.add('active');
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
}

function showEuropeComp(comp) {
    document.querySelectorAll('.europe-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event.target.classList.add('active');
    
    const content = document.getElementById('europe-content');
    content.innerHTML = '<p class="empty-state">Competition data will be available during the season.</p>';
}

function showLoading(show) {
    const overlay = document.getElementById('loading-overlay');
    if (show) {
        overlay.classList.add('active');
    } else {
        overlay.classList.remove('active');
    }
}

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function addNews(text) {
    const newsFeed = document.getElementById('news-feed');
    const newsItem = document.createElement('div');
    newsItem.className = 'news-item';
    newsItem.innerHTML = `
        <p>${text}</p>
        <span class="news-time">Just now</span>
    `;
    newsFeed.insertBefore(newsItem, newsFeed.firstChild);
    
    // Keep only last 10 news items
    while (newsFeed.children.length > 10) {
        newsFeed.removeChild(newsFeed.lastChild);
    }
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(0) + 'K';
    }
    return num.toString();
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    initGame();
});
