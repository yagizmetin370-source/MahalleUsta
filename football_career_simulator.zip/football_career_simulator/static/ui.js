// UI Utilities and Additional Functions

// Format currency
function formatCurrency(amount, currency = '£') {
    if (amount >= 1000000) {
        return currency + (amount / 1000000).toFixed(1) + 'M';
    } else if (amount >= 1000) {
        return currency + (amount / 1000).toFixed(0) + 'K';
    }
    return currency + amount.toLocaleString();
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { 
        day: 'numeric', 
        month: 'short', 
        year: 'numeric' 
    });
}

// Generate match schedule
function generateMatchSchedule() {
    if (!gameState.player) return;
    
    const club = gameState.clubs.find(c => c.id === gameState.player.club_id);
    if (!club) return;
    
    const leagueClubs = gameState.clubs.filter(c => 
        c.league_id === club.league_id && c.id !== club.id
    ).slice(0, 19);
    
    const schedule = [];
    for (let week = gameState.currentWeek; week <= Math.min(gameState.currentWeek + 5, 38); week++) {
        const opponent = leagueClubs[week % leagueClubs.length];
        const isHome = week % 2 === 0;
        
        schedule.push({
            week,
            home: isHome ? club.name : opponent.name,
            away: isHome ? opponent.name : club.name,
            competition: 'League',
            played: false
        });
    }
    
    const scheduleHTML = schedule.map(match => `
        <div class="card match-card">
            <div class="match-info">
                <div class="match-week">Week ${match.week}</div>
                <div class="match-teams">
                    <span class="team">${match.home}</span>
                    <span class="vs">vs</span>
                    <span class="team">${match.away}</span>
                </div>
                <div class="match-competition">${match.competition}</div>
            </div>
            ${match.week === gameState.currentWeek ? 
                '<button class="btn btn-primary btn-small" onclick="playMatch()">PLAY</button>' : 
                '<span class="match-upcoming">Upcoming</span>'
            }
        </div>
    `).join('');
    
    document.getElementById('match-schedule').innerHTML = scheduleHTML || '<p class="empty-state">No upcoming matches</p>';
}

// Generate career history timeline
function generateCareerHistory() {
    if (!gameState.careerHistory || gameState.careerHistory.length === 0) {
        document.getElementById('career-history').innerHTML = '<p class="empty-state">Your career story will appear here</p>';
        return;
    }
    
    const historyHTML = gameState.careerHistory.map(event => `
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <h4>${event.title}</h4>
                <p>${event.description}</p>
                <span class="timeline-date">${event.date}</span>
            </div>
        </div>
    `).join('');
    
    document.getElementById('career-history').innerHTML = historyHTML;
}

// Player comparison
function comparePlayer(player1, player2) {
    const comparison = {
        overall: player1.overall - player2.overall,
        pace: player1.attributes.pace - player2.attributes.pace,
        shooting: player1.attributes.shooting - player2.attributes.shooting,
        passing: player1.attributes.passing - player2.attributes.passing,
        dribbling: player1.attributes.dribbling - player2.attributes.dribbling,
        defending: player1.attributes.defending - player2.attributes.defending,
        physical: player1.attributes.physical - player2.attributes.physical
    };
    
    return comparison;
}

// Award system
const Awards = {
    BALLON_DOR: 'Ballon d\'Or',
    GOLDEN_BOOT: 'Golden Boot',
    GOLDEN_GLOVE: 'Golden Glove',
    YOUNG_PLAYER: 'Young Player of the Year',
    PLAYER_OF_YEAR: 'Player of the Year'
};

function checkAwards(player, season) {
    const awards = [];
    
    // Golden Boot (most goals)
    if (player.season_goals >= 30) {
        awards.push(Awards.GOLDEN_BOOT);
    }
    
    // Young Player (under 23 with high performance)
    if (player.age < 23 && player.overall >= 80) {
        awards.push(Awards.YOUNG_PLAYER);
    }
    
    // Player of the Year (high rating and performance)
    if (player.season_matches >= 25) {
        const avgRating = player.season_rating_total / player.season_matches;
        if (avgRating >= 8.0 && player.overall >= 85) {
            awards.push(Awards.PLAYER_OF_YEAR);
        }
    }
    
    // Ballon d'Or (exceptional season)
    if (player.season_goals + player.season_assists >= 50 && player.overall >= 88) {
        awards.push(Awards.BALLON_DOR);
    }
    
    return awards;
}

// Generate transfer rumors
function generateTransferRumors() {
    if (!gameState.player || Math.random() > 0.3) return;
    
    const interestedClubs = gameState.clubs.filter(club => {
        const reputationDiff = Math.abs(club.reputation - gameState.player.overall);
        return reputationDiff < 10 && club.id !== gameState.player.club_id;
    }).slice(0, 3);
    
    if (interestedClubs.length > 0) {
        const club = interestedClubs[Math.floor(Math.random() * interestedClubs.length)];
        addNews(`Transfer Rumor: ${club.name} interested in signing you!`);
    }
}

// Reputation system
function updateReputation(player, performance) {
    const currentRep = player.reputation || 50;
    let change = 0;
    
    if (performance.rating >= 8.5) {
        change = 2;
    } else if (performance.rating >= 7.5) {
        change = 1;
    } else if (performance.rating < 6.0) {
        change = -1;
    }
    
    if (performance.goals >= 2) {
        change += 2;
    } else if (performance.goals === 1) {
        change += 1;
    }
    
    player.reputation = Math.max(0, Math.min(100, currentRep + change));
}

// Morale system
function updateMorale(player, result) {
    const currentMorale = player.morale || 75;
    let change = 0;
    
    // Win/Loss effect
    if (result === 'win') {
        change = 3;
    } else if (result === 'draw') {
        change = 1;
    } else {
        change = -3;
    }
    
    // Playing time effect
    if (player.season_matches > 0) {
        change += 1;
    }
    
    player.morale = Math.max(0, Math.min(100, currentMorale + change));
    
    // Morale affects performance
    if (player.morale < 50) {
        player.form_modifier = -0.1;
    } else if (player.morale > 80) {
        player.form_modifier = 0.1;
    } else {
        player.form_modifier = 0;
    }
}

// Social media/popularity
function updatePopularity(player, performance) {
    const currentPop = player.popularity || 0;
    let change = 0;
    
    if (performance.goals >= 3) {
        change = 1000;
    } else if (performance.goals >= 2) {
        change = 500;
    } else if (performance.rating >= 9.0) {
        change = 300;
    }
    
    player.popularity = currentPop + change;
}

// Press conference responses
const PressResponses = {
    confident: "We're going to win this match!",
    humble: "We'll do our best and see what happens.",
    tactical: "We've studied the opponent and have a plan.",
    motivated: "The team is ready and highly motivated."
};

function handlePressConference(response) {
    // Affect morale and pressure
    switch(response) {
        case 'confident':
            gameState.player.pressure = (gameState.player.pressure || 50) + 10;
            gameState.player.morale = (gameState.player.morale || 75) + 5;
            break;
        case 'humble':
            gameState.player.pressure = (gameState.player.pressure || 50) - 5;
            break;
        case 'tactical':
            gameState.player.pressure = (gameState.player.pressure || 50) + 3;
            break;
    }
}

// International career
function checkInternationalCallUp(player) {
    const callUpChance = player.overall / 100;
    
    if (Math.random() < callUpChance && player.overall >= 75) {
        addNews(`🌍 You've been called up to the ${player.nationality} national team!`);
        return true;
    }
    return false;
}

// Sponsor deals
function checkSponsorDeals(player) {
    if (player.popularity >= 10000 && Math.random() < 0.2) {
        const sponsorValue = player.popularity * 10;
        addNews(`💼 New sponsorship deal worth £${formatNumber(sponsorValue)}!`);
        player.sponsorship_income = (player.sponsorship_income || 0) + sponsorValue;
    }
}

// Youth development
function trainYouthAttribute(player, attribute) {
    if (player.age > 23) {
        showToast("You're too experienced for youth training!", "warning");
        return false;
    }
    
    const improvement = playerGrowth.trainAttribute(player, attribute);
    return improvement;
}

// Team chemistry
function calculateTeamChemistry(player, teammates) {
    let chemistry = 50;
    
    // Same nationality bonus
    const sameNationality = teammates.filter(t => t.nationality === player.nationality).length;
    chemistry += sameNationality * 2;
    
    // Time at club
    chemistry += Math.min(20, player.seasons_at_club * 5);
    
    return Math.min(100, chemistry);
}

// Match statistics visualization
function createMatchStatsChart(match) {
    const stats = {
        possession: [match.home_possession || 50, match.away_possession || 50],
        shots: [match.home_shots || 10, match.away_shots || 10],
        passes: [match.home_passes || 400, match.away_passes || 400]
    };
    
    return stats;
}

// Skill moves unlocking
const SkillMoves = {
    STEPOVER: { required: 75, name: 'Stepover' },
    ROULETTE: { required: 80, name: 'Roulette' },
    ELASTICO: { required: 85, name: 'Elastico' },
    RAINBOW: { required: 90, name: 'Rainbow Flick' }
};

function checkUnlockedSkills(player) {
    const unlocked = [];
    for (const [key, skill] of Object.entries(SkillMoves)) {
        if (player.attributes.dribbling >= skill.required) {
            unlocked.push(skill.name);
        }
    }
    return unlocked;
}

// Weekly training schedule
function generateTrainingSchedule() {
    return [
        { day: 'Monday', focus: 'Recovery', intensity: 'Low' },
        { day: 'Tuesday', focus: 'Technical', intensity: 'Medium' },
        { day: 'Wednesday', focus: 'Tactical', intensity: 'Medium' },
        { day: 'Thursday', focus: 'Physical', intensity: 'High' },
        { day: 'Friday', focus: 'Match Prep', intensity: 'Low' }
    ];
}

// Refresh UI elements
function refreshUI() {
    if (gameState.player) {
        updatePlayerCard();
        updateSeasonStats();
        generateMatchSchedule();
        generateCareerHistory();
    }
}

// Auto-save feature
let autoSaveInterval;
function enableAutoSave(minutes = 5) {
    if (autoSaveInterval) {
        clearInterval(autoSaveInterval);
    }
    
    autoSaveInterval = setInterval(() => {
        if (gameState.player) {
            saveGame();
            console.log('Auto-saved game');
        }
    }, minutes * 60 * 1000);
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl+S to save
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        saveGame();
    }
    
    // Space to play match (when on dashboard)
    if (e.key === ' ' && document.getElementById('tab-dashboard').classList.contains('active')) {
        e.preventDefault();
        playMatch();
    }
});

// Initialize UI enhancements
function initUIEnhancements() {
    enableAutoSave();
    
    // Add keyboard shortcut hints
    console.log('Keyboard Shortcuts:');
    console.log('Ctrl+S - Quick Save');
    console.log('Space - Play Next Match');
}

// Call on load
document.addEventListener('DOMContentLoaded', () => {
    initUIEnhancements();
});
