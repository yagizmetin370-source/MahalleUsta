from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import json
import random
import os
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Load game data
def load_json_file(filename):
    filepath = os.path.join('data', filename)
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading {filename}: {e}")
        return []

# Initialize data
players_data = load_json_file('players.json')
clubs_data = load_json_file('clubs.json')
leagues_data = load_json_file('leagues.json')
tournaments_data = load_json_file('tournaments.json')

# Career save data
career_save = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/game_data')
def get_game_data():
    return jsonify({
        'players': players_data,
        'clubs': clubs_data,
        'leagues': leagues_data,
        'tournaments': tournaments_data
    })

@app.route('/api/new_career', methods=['POST'])
def new_career():
    global career_save
    
    data = request.json
    name = data.get('name', 'Player')
    nationality = data.get('nationality', 'England')
    position = data.get('position', 'ST')
    club_id = data.get('club_id', 1)
    
    # Create player
    player = {
        'id': 99999,
        'name': name,
        'age': 18,
        'nationality': nationality,
        'position': position,
        'club_id': club_id,
        'overall': 65,
        'potential': random.randint(80, 95),
        'value': 5000000,
        'wage': 10000,
        'contract_years': 3,
        'attributes': {
            'pace': random.randint(60, 75),
            'shooting': random.randint(60, 75),
            'passing': random.randint(60, 75),
            'dribbling': random.randint(60, 75),
            'defending': random.randint(30, 50),
            'physical': random.randint(60, 75)
        },
        'season_matches': 0,
        'season_goals': 0,
        'season_assists': 0,
        'season_rating_total': 0,
        'career_matches': 0,
        'career_goals': 0,
        'career_assists': 0,
        'career_trophies': 0,
        'reputation': 50,
        'morale': 75
    }
    
    career_save = {
        'player': player,
        'season': '2024/25',
        'week': 1
    }
    
    return jsonify({
        'success': True,
        'player': player
    })

@app.route('/api/sim_match', methods=['POST'])
def simulate_match():
    global career_save
    
    if not career_save:
        return jsonify({'success': False, 'message': 'No active career'})
    
    data = request.json
    player = career_save['player']
    
    # Find clubs
    player_club = next((c for c in clubs_data if c['id'] == player['club_id']), None)
    if not player_club:
        return jsonify({'success': False, 'message': 'Club not found'})
    
    # Find opponent
    league_clubs = [c for c in clubs_data if c['league_id'] == player_club['league_id'] and c['id'] != player_club['id']]
    opponent = random.choice(league_clubs) if league_clubs else None
    
    if not opponent:
        return jsonify({'success': False, 'message': 'No opponent found'})
    
    # Simulate match
    is_home = random.choice([True, False])
    home_club = player_club if is_home else opponent
    away_club = opponent if is_home else player_club
    
    # Calculate team strengths
    home_strength = home_club.get('reputation', 75)
    away_strength = away_club.get('reputation', 75)
    
    # Home advantage
    home_strength *= 1.1
    
    # Calculate goals
    home_goals = max(0, min(6, int((home_strength / away_strength) * 1.5 + random.random() * 1.5)))
    away_goals = max(0, min(6, int((away_strength / home_strength) * 1.3 + random.random() * 1.5)))
    
    # Player performance
    base_rating = player['overall'] / 10
    rating = base_rating + (random.random() - 0.5) * 2
    rating = max(4.0, min(10.0, rating))
    rating = round(rating, 1)
    
    # Goals and assists
    player_goals = 0
    player_assists = 0
    
    if player['position'] in ['ST', 'LW', 'RW', 'CAM']:
        if random.random() < 0.3:
            player_goals = random.randint(0, 2)
        if random.random() < 0.25:
            player_assists = random.randint(0, 2)
    
    # Update player stats
    player['season_matches'] += 1
    player['season_goals'] += player_goals
    player['season_assists'] += player_assists
    player['season_rating_total'] += rating
    player['career_matches'] += 1
    player['career_goals'] += player_goals
    player['career_assists'] += player_assists
    
    # Small growth chance
    if random.random() < 0.1 and player['overall'] < player['potential']:
        player['overall'] += 1
        player['value'] = int(player['value'] * 1.1)
    
    match_result = {
        'home': home_club['name'],
        'away': away_club['name'],
        'home_score': home_goals,
        'away_score': away_goals,
        'player_rating': rating,
        'player_goals': player_goals,
        'player_assists': player_assists,
        'motm': rating >= 8.5
    }
    
    career_save['player'] = player
    
    return jsonify({
        'success': True,
        'match': match_result,
        'player': player
    })

@app.route('/api/train', methods=['POST'])
def train_player():
    global career_save
    
    if not career_save:
        return jsonify({'success': False, 'message': 'No active career'})
    
    data = request.json
    attribute = data.get('attribute')
    player = career_save['player']
    
    if attribute not in player['attributes']:
        return jsonify({'success': False, 'message': 'Invalid attribute'})
    
    # Train attribute
    improvement = random.randint(1, 3)
    current = player['attributes'][attribute]
    player['attributes'][attribute] = min(99, current + improvement)
    
    # Recalculate overall
    attrs = player['attributes']
    total = sum([
        attrs['pace'] * 1.0,
        attrs['shooting'] * 1.2,
        attrs['passing'] * 1.1,
        attrs['dribbling'] * 1.1,
        attrs['defending'] * 0.5,
        attrs['physical'] * 1.0
    ])
    new_overall = int(total / 6)
    player['overall'] = min(player['potential'], new_overall)
    
    career_save['player'] = player
    
    return jsonify({
        'success': True,
        'player': player,
        'improvement': improvement
    })

@app.route('/api/save_career', methods=['POST'])
def save_career():
    global career_save
    
    try:
        with open('career_save.json', 'w') as f:
            json.dump(career_save, f, indent=2)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/load_career')
def load_career():
    global career_save
    
    try:
        if os.path.exists('career_save.json'):
            with open('career_save.json', 'r') as f:
                career_save = json.load(f)
            return jsonify({'success': True, 'gameState': career_save})
        else:
            return jsonify({'success': False, 'message': 'No saved career found'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/transfers')
def get_transfers():
    # Generate random transfer offers
    if not career_save:
        return jsonify({'offers': []})
    
    player = career_save['player']
    offers = []
    
    # Chance of transfer offers
    if random.random() < 0.3:
        interested_clubs = [c for c in clubs_data if abs(c.get('reputation', 75) - player['overall']) < 10]
        if interested_clubs:
            club = random.choice(interested_clubs[:5])
            offer = {
                'club': club['name'],
                'club_id': club['id'],
                'transfer_fee': int(player['value'] * (0.8 + random.random() * 0.4)),
                'wage': int(player['wage'] * (1.1 + random.random() * 0.3)),
                'contract_years': random.randint(2, 5)
            }
            offers.append(offer)
    
    return jsonify({'offers': offers})

@app.route('/api/league_table/<int:league_id>')
def get_league_table(league_id):
    league_clubs = [c for c in clubs_data if c.get('league_id') == league_id]
    
    # Sort by reputation (simulating standings)
    league_clubs.sort(key=lambda x: x.get('reputation', 0), reverse=True)
    
    table = []
    for i, club in enumerate(league_clubs[:20]):
        points = 38 - i * 2 + random.randint(0, 10)
        wins = points // 3
        draws = points % 3
        losses = 14 - wins - draws
        gd = wins * 2 - losses * 2
        
        table.append({
            'position': i + 1,
            'club': club['name'],
            'points': points,
            'wins': wins,
            'draws': draws,
            'losses': losses,
            'gd': gd
        })
    
    return jsonify({'table': table})

if __name__ == '__main__':
    print("=" * 60)
    print("FOOTBALL CAREER SIMULATOR - AAA EDITION")
    print("=" * 60)
    print(f"Players loaded: {len(players_data)}")
    print(f"Clubs loaded: {len(clubs_data)}")
    print(f"Leagues loaded: {len(leagues_data)}")
    print(f"Tournaments loaded: {len(tournaments_data)}")
    print("=" * 60)
    print("Server starting on http://localhost:5000")
    print("=" * 60)
    
    app.run(debug=True, host='0.0.0.0', port=5000)
